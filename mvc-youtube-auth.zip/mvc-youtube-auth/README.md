# MVC YouTube (Register/Login/Logout) + SQLite + Session

## Features
- MVC structure: Controllers / Services / Repositories / Views (EJS)
- **Auth**: Register / Login / Logout
- **SQLite**:
  - `users` table (email, fullName, passwordHash, createdAt)
  - `favorites` table (per-user saved videos)
- **Sessions stored in SQLite** (`connect-sqlite3`) ✅
- After login/register → redirects to `/videos` (main page)
- `/videos` page:
  - Top: search YouTube videos
  - Bottom: list of saved videos + delete
- UI with Bootstrap

---

## Run locally
1. Install:
```bash
npm install
```

2. Create `.env`:
```bash
cp .env.example .env
```

3. Start:
```bash
npm start
```
Then open: `http://localhost:1000`

> **Optional (real search):** add `YOUTUBE_API_KEY` in `.env`.

---

## Render deployment
1. Push to GitHub
2. In Render:
   - **New** → **Web Service**
   - Connect repo
   - Build Command: `npm install`
   - Start Command: `npm start`
3. In **Environment** set:
   - `SESSION_SECRET` (any long random string)
   - `YOUTUBE_API_KEY` (optional)

Render provides `PORT` automatically. The app uses `process.env.PORT` (fallback 1000).

---

## Project structure
```
src/
  controllers/
  services/
  repositories/
  routes/
  middleware/
  db/
  views/
  public/
```
