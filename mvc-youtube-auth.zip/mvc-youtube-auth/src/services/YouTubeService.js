class YouTubeService {
  constructor(apiKey) {
    this.apiKey = apiKey;
  }

  async searchVideos(query) {
    const q = (query || '').trim();
    if (!q) return { items: [], warning: null };

    if (!this.apiKey) {
      return {
        items: [],
        warning: 'Missing YOUTUBE_API_KEY. Add it in .env (local) or Render Environment.'
      };
    }

    const url = new URL('https://www.googleapis.com/youtube/v3/search');
    url.searchParams.set('part', 'snippet');
    url.searchParams.set('type', 'video');
    url.searchParams.set('maxResults', '8');
    url.searchParams.set('q', q);
    url.searchParams.set('key', this.apiKey);

    const res = await fetch(url.toString());
    if (!res.ok) {
      const text = await res.text();
      return {
        items: [],
        warning: `YouTube API error (${res.status}): ${text.slice(0, 120)}...`
      };
    }

    const data = await res.json();
    const items = (data.items || []).map((it) => {
      const sn = it.snippet || {};
      return {
        videoId: it.id?.videoId,
        title: sn.title || '',
        channelTitle: sn.channelTitle || '',
        thumbnailUrl:
          sn.thumbnails?.medium?.url || sn.thumbnails?.default?.url || sn.thumbnails?.high?.url || null
      };
    }).filter(v => v.videoId);

    return { items, warning: null };
  }
}

module.exports = YouTubeService;
