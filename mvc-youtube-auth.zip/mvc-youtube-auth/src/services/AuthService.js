const bcrypt = require('bcryptjs');
const UserRepository = require('../repositories/UserRepository');

class AuthService {
  constructor() {
    this.users = new UserRepository();
  }

  _sanitizeUser(userRow) {
    if (!userRow) return null;
    const { passwordHash, ...safe } = userRow;
    return safe;
  }

  async register(dto) {
    const email = (dto.email || '').toLowerCase().trim();
    const fullName = (dto.fullName || '').trim();
    const password = (dto.password || '').trim();

    if (!email || !fullName || !password) {
      throw new Error('All fields are required');
    }

    const existing = await this.users.findByEmail(email);
    if (existing) throw new Error('Email already registered');

    const passwordHash = await bcrypt.hash(password, 10);
    const created = await this.users.create({ email, fullName, passwordHash });
    return this._sanitizeUser(created);
  }

  async login(dto) {
    const email = (dto.email || '').toLowerCase().trim();
    const password = (dto.password || '').trim();

    if (!email || !password) throw new Error('Email and password are required');

    const user = await this.users.findByEmail(email);
    if (!user) throw new Error('Invalid email or password');

    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) throw new Error('Invalid email or password');

    return this._sanitizeUser(user);
  }
}

module.exports = AuthService;
