const path = require('path');
const fs = require('fs');
const express = require('express');
const session = require('express-session');
const SQLiteStoreFactory = require('connect-sqlite3');
const helmet = require('helmet');
const { initDb } = require('./db/sqlite');

const authRoutes = require('./routes/authRoutes');
const videoRoutes = require('./routes/videoRoutes');

function ensureDir(dirPath) {
  if (!fs.existsSync(dirPath)) fs.mkdirSync(dirPath, { recursive: true });
}

function createApp() {
  const app = express();

  // DB init (creates tables if missing)
  initDb().catch((e) => console.error('DB init failed:', e));

  app.use(helmet({
    contentSecurityPolicy: false // keep simple for bootstrap CDN + thumbnails
  }));

  // Body
  app.use(express.urlencoded({ extended: true }));

  // Static
  app.use('/public', express.static(path.join(__dirname, 'public')));

  // View engine
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, 'views'));

  // Session store in SQLite
  const SQLiteStore = SQLiteStoreFactory(session);
  const dataDir = path.join(process.cwd(), 'data');
  ensureDir(dataDir);

  app.use(
    session({
      store: new SQLiteStore({
        db: 'sessions.db',
        dir: dataDir
      }),
      secret: process.env.SESSION_SECRET || 'dev_secret_change_me',
      resave: false,
      saveUninitialized: false,
      cookie: {
        httpOnly: true,
        sameSite: 'lax'
      }
    })
  );

  // Make session user available to views
  app.use((req, res, next) => {
    res.locals.user = req.session.user || null;
    next();
  });

  // Routes
  app.get('/', (req, res) => {
    if (req.session.user) return res.redirect('/videos');
    return res.redirect('/auth/login');
  });

  app.use('/auth', authRoutes);
  app.use('/videos', videoRoutes);

  // 404
  app.use((req, res) => {
    res.status(404).render('notfound');
  });

  return app;
}

module.exports = { createApp };
