const { get, run } = require('../db/sqlite');

class UserRepository {
  async findByEmail(email) {
    return get('SELECT * FROM users WHERE email = ? LIMIT 1;', [email.toLowerCase().trim()]);
  }

  async findById(id) {
    return get('SELECT * FROM users WHERE id = ? LIMIT 1;', [id]);
  }

  async create({ email, fullName, passwordHash }) {
    const result = await run(
      'INSERT INTO users (email, fullName, passwordHash) VALUES (?, ?, ?);',
      [email.toLowerCase().trim(), fullName.trim(), passwordHash]
    );
    return this.findById(result.lastID);
  }
}

module.exports = UserRepository;
