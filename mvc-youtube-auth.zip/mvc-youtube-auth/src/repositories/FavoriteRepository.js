const { all, run } = require('../db/sqlite');

class FavoriteRepository {
  async listByUser(userId) {
    return all(
      'SELECT * FROM favorites WHERE userId = ? ORDER BY createdAt DESC;',
      [userId]
    );
  }

  async add(userId, fav) {
    await run(
      `INSERT OR IGNORE INTO favorites (userId, videoId, title, channelTitle, thumbnailUrl)
       VALUES (?, ?, ?, ?, ?);`,
      [userId, fav.videoId, fav.title, fav.channelTitle, fav.thumbnailUrl || null]
    );
  }

  async remove(userId, videoId) {
    await run('DELETE FROM favorites WHERE userId = ? AND videoId = ?;', [userId, videoId]);
  }
}

module.exports = FavoriteRepository;
