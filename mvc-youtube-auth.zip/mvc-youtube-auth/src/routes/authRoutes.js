const express = require('express');
const AuthController = require('../controllers/AuthController');

const router = express.Router();
const controller = new AuthController();

router.get('/register', controller.showRegister);
router.post('/register', controller.register);
router.get('/login', controller.showLogin);
router.post('/login', controller.login);
router.post('/logout', controller.logout);

module.exports = router;
