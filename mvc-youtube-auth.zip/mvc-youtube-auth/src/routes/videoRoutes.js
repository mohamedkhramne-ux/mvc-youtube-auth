const express = require('express');
const VideoController = require('../controllers/VideoController');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();
const controller = new VideoController();

router.get('/', requireAuth, controller.showPage);
router.post('/save', requireAuth, controller.save);
router.post('/delete', requireAuth, controller.remove);

module.exports = router;
