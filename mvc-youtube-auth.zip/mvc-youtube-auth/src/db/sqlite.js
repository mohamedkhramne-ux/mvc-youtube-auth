const path = require('path');
const fs = require('fs');
const sqlite3 = require('sqlite3').verbose();

function ensureDir(dirPath) {
  if (!fs.existsSync(dirPath)) fs.mkdirSync(dirPath, { recursive: true });
}

const dataDir = path.join(process.cwd(), 'data');
ensureDir(dataDir);

const appDbPath = path.join(dataDir, 'app.db');

const db = new sqlite3.Database(appDbPath);

db.exec('PRAGMA foreign_keys = ON;');

function run(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) return reject(err);
      resolve({ lastID: this.lastID, changes: this.changes });
    });
  });
}

function get(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) return reject(err);
      resolve(row);
    });
  });
}

function all(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) return reject(err);
      resolve(rows);
    });
  });
}

async function initDb() {
  await run(
    `CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL UNIQUE,
      fullName TEXT NOT NULL,
      passwordHash TEXT NOT NULL,
      createdAt TEXT NOT NULL DEFAULT (datetime('now'))
    );`
  );

  await run(
    `CREATE TABLE IF NOT EXISTS favorites (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId INTEGER NOT NULL,
      videoId TEXT NOT NULL,
      title TEXT NOT NULL,
      channelTitle TEXT NOT NULL,
      thumbnailUrl TEXT,
      createdAt TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(userId, videoId),
      FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
    );`
  );
}

module.exports = { db, run, get, all, initDb, appDbPath };
