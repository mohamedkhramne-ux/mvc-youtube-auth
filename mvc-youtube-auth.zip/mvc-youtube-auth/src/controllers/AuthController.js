const AuthService = require('../services/AuthService');

class AuthController {
  constructor() {
    this.authService = new AuthService();

    // bind
    this.showRegister = this.showRegister.bind(this);
    this.register = this.register.bind(this);
    this.showLogin = this.showLogin.bind(this);
    this.login = this.login.bind(this);
    this.logout = this.logout.bind(this);
  }

  showRegister(req, res) {
    res.render('register', { error: null, values: { email: '', fullName: '' } });
  }

  async register(req, res) {
    try {
      const user = await this.authService.register(req.body);
      req.session.user = { id: user.id, email: user.email, fullName: user.fullName };
      return res.redirect('/videos');
    } catch (err) {
      return res.status(400).render('register', {
        error: err.message || 'Registration failed',
        values: { email: req.body.email || '', fullName: req.body.fullName || '' }
      });
    }
  }

  showLogin(req, res) {
    res.render('login', { error: null, values: { email: '' } });
  }

  async login(req, res) {
    try {
      const user = await this.authService.login(req.body);
      req.session.user = { id: user.id, email: user.email, fullName: user.fullName };
      return res.redirect('/videos');
    } catch (err) {
      return res.status(401).render('login', {
        error: err.message || 'Login failed',
        values: { email: req.body.email || '' }
      });
    }
  }

  logout(req, res) {
    req.session.destroy(() => {
      res.redirect('/auth/login');
    });
  }
}

module.exports = AuthController;
