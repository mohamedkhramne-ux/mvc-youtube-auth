const FavoriteRepository = require('../repositories/FavoriteRepository');
const YouTubeService = require('../services/YouTubeService');

class VideoController {
  constructor() {
    this.favoritesRepo = new FavoriteRepository();
    this.youtube = new YouTubeService(process.env.YOUTUBE_API_KEY);

    this.showPage = this.showPage.bind(this);
    this.save = this.save.bind(this);
    this.remove = this.remove.bind(this);
  }

  async showPage(req, res) {
    const user = req.session.user;
    const q = (req.query.q || '').trim();

    const favorites = await this.favoritesRepo.listByUser(user.id);
    const { items: results, warning } = await this.youtube.searchVideos(q);

    return res.render('videos', {
      q,
      results,
      favorites,
      warning,
      message: req.query.msg || null
    });
  }

  async save(req, res) {
    const userId = req.session.user.id;
    const { videoId, title, channelTitle, thumbnailUrl } = req.body;
    if (!videoId) return res.redirect('/videos?msg=Missing%20videoId');

    await this.favoritesRepo.add(userId, {
      videoId,
      title: title || 'Untitled',
      channelTitle: channelTitle || 'Unknown',
      thumbnailUrl: thumbnailUrl || null
    });

    const q = (req.body.returnQ || '').trim();
    const back = q ? `/videos?q=${encodeURIComponent(q)}&msg=${encodeURIComponent('Saved!')}` : '/videos?msg=Saved!';
    return res.redirect(back);
  }

  async remove(req, res) {
    const userId = req.session.user.id;
    const { videoId } = req.body;
    if (videoId) await this.favoritesRepo.remove(userId, videoId);

    return res.redirect('/videos?msg=Deleted');
  }
}

module.exports = VideoController;
